# generics 0.1.0

* Maintainer changed to Hadley Wickham.

* Re-licensed with MIT license.

* New `min_grid()`, `required_pkgs()`, and `tunable()` generics.

# `generics` 0.0.2

* Removed the `data` argument to `augment` to resolve issues with `broom`. 

# `generics` 0.0.1

First CRAN version


