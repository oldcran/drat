library(testthat)
library(downlit)

test_check("downlit")
