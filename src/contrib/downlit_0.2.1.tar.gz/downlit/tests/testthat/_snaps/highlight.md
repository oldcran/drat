# ansi escapes are converted to html

    [1] "<span class='c'># <span style='color: #BB0000;'>hello</span></span>"

---

    [1] "<span class='c'># <span style='color: #BB0000;'>hello</span></span>"

