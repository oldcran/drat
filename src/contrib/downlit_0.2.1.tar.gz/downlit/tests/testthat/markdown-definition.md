Term 1 (`base::t()`)

:   Definition 1 (`base::t()`)
