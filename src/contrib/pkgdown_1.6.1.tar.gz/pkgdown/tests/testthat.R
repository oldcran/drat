library(testthat)
library(pkgdown)

test_check("pkgdown")
