#' A
#' @export
a <- function() {}

#' B
#' @export
b <- function() {}

#' C
#' @export
c <- function() {}

#' D
#' @usage
#' \special{?topic}
#' @export
`?` <- function() {}
